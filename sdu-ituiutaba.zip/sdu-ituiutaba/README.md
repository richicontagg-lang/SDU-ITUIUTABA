# SDU Ituiutaba — Sistema de Denúncias Urbanas

**Stack:** React.js · Node.js + Express · PostgreSQL · OpenStreetMap (Leaflet) · PWA

---

## ▶️ Rodar localmente (VS Code)

### Pré-requisitos
- Node.js 20+
- Docker Desktop

### 1. Suba o PostgreSQL
```bash
docker-compose up postgres -d
```

### 2. Configure o backend
```bash
cd server
npm install
npm run dev
```
> A API roda em http://localhost:3001

### 3. Configure o frontend (novo terminal)
```bash
cd client
npm install
npm run dev
```
> O app roda em http://localhost:5173

---

## 👤 Credenciais padrão (admin)

| Campo | Valor |
|-------|-------|
| E-mail | admin@ituiutaba.mg.gov.br |
| Senha | admin123 |

---

## 🗺️ Funcionalidades

- Mapa interativo com denúncias geolocalizadas (OpenStreetMap)
- Cadastro e login de cidadãos
- Envio de denúncias com foto, GPS e categoria
- Acompanhamento de status com timeline
- Avaliação do atendimento (⭐)
- Painel administrativo com KPIs e gestão de status
- PWA instalável no celular

---

## 📁 Estrutura

```
sdu-ituiutaba/
├── client/          # React PWA (Vite)
├── server/          # Node.js + Express API
└── docker-compose.yml
```
