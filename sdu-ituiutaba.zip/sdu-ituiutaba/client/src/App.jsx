import { Routes, Route, Navigate } from 'react-router-dom';
import { useApp } from './context/AppContext';
import Login            from './components/Auth/Login';
import Register         from './components/Auth/Register';
import Home             from './components/Home';
import NovaDenuncia     from './components/Denuncia/NovaDenuncia';
import ListaDenuncias   from './components/Denuncia/ListaDenuncias';
import DetalheDenuncia  from './components/Denuncia/DetalheDenuncia';
import Sucesso          from './components/Denuncia/Sucesso';
import AdminPainel      from './components/Admin/Painel';
import AdminDetalhe     from './components/Admin/AdminDetalhe';
import Toast            from './components/UI/Toast';

function Private({ children }) {
  const { user, loading } = useApp();
  if (loading) return <div className="loading">Carregando...</div>;
  return user ? children : <Navigate to="/login" replace />;
}

function AdminRoute({ children }) {
  const { user } = useApp();
  return user?.role === 'admin' || user?.role === 'gestor'
    ? children
    : <Navigate to="/" replace />;
}

export default function App() {
  const { toast } = useApp();
  return (
    <>
      <Routes>
        <Route path="/login"       element={<Login />} />
        <Route path="/register"    element={<Register />} />
        <Route path="/"            element={<Private><Home /></Private>} />
        <Route path="/nova"        element={<Private><NovaDenuncia /></Private>} />
        <Route path="/minhas"      element={<Private><ListaDenuncias /></Private>} />
        <Route path="/denuncia/:id" element={<Private><DetalheDenuncia /></Private>} />
        <Route path="/sucesso"     element={<Private><Sucesso /></Private>} />
        <Route path="/admin"       element={<Private><AdminRoute><AdminPainel /></AdminRoute></Private>} />
        <Route path="/admin/:id"   element={<Private><AdminRoute><AdminDetalhe /></AdminRoute></Private>} />
        <Route path="*"            element={<Navigate to="/" replace />} />
      </Routes>
      {toast && <Toast msg={toast} />}
    </>
  );
}
