import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import { useApp } from '../../context/AppContext';

const STATUS_OPTIONS = ['Aberta', 'Em andamento', 'Resolvida', 'Recusada'];

const statusBadge = s => {
  const map = { Aberta: 'aberta', 'Em andamento': 'andamento', Resolvida: 'resolvida', Recusada: 'recusada' };
  return `badge badge-${map[s] || 'aberta'}`;
};

export default function AdminDetalhe() {
  const { id } = useParams();
  const nav    = useNavigate();
  const { showToast } = useApp();
  const [denuncia, setDenuncia] = useState(null);
  const [novoStatus, setNovoStatus] = useState('');
  const [nota, setNota]         = useState('');
  const [saving, setSaving]     = useState(false);

  useEffect(() => {
    api.get(`/denuncias/${id}`).then(r => {
      setDenuncia(r.data);
      setNovoStatus(r.data.status);
    });
  }, [id]);

  async function salvar() {
    setSaving(true);
    try {
      await api.patch(`/admin/denuncias/${id}/status`, { status: novoStatus, nota });
      showToast('Status atualizado!');
      nav('/admin');
    } catch {
      showToast('Erro ao atualizar status');
    } finally {
      setSaving(false);
    }
  }

  if (!denuncia) return <div className="loading">Carregando...</div>;

  const fmt = iso => new Date(iso).toLocaleDateString('pt-BR');

  return (
    <div className="screen">
      <div className="page-header">
        <button className="back-btn" onClick={() => nav('/admin')}>←</button>
        <div>
          <div>{denuncia.categoria}</div>
          <div style={{ fontSize: '.72rem', color: 'var(--gray-5)', fontWeight: 400 }}>#{denuncia.protocolo}</div>
        </div>
        <span className={statusBadge(denuncia.status)} style={{ marginLeft: 'auto' }}>{denuncia.status}</span>
      </div>

      <div className="scroll-body">
        {denuncia.foto_url && <img src={denuncia.foto_url} alt="foto" className="detalhe-foto" />}

        <div className="card">
          <p style={{ fontWeight: 600, marginBottom: '.4rem' }}>Dados da denúncia</p>
          <p style={{ fontSize: '.85rem', color: 'var(--gray-5)' }}>📍 {denuncia.endereco}</p>
          <p style={{ fontSize: '.9rem', marginTop: '.4rem' }}>{denuncia.descricao}</p>
          <p style={{ fontSize: '.75rem', color: 'var(--gray-5)', marginTop: '.5rem' }}>Enviada em {fmt(denuncia.created_at)}</p>
        </div>

        <div className="card">
          <p style={{ fontWeight: 600, marginBottom: '.5rem' }}>Atualizar status</p>
          <select className="status-select" value={novoStatus} onChange={e => setNovoStatus(e.target.value)}>
            {STATUS_OPTIONS.map(s => <option key={s}>{s}</option>)}
          </select>
          <div className="field">
            <label>Nota interna (opcional)</label>
            <input value={nota} onChange={e => setNota(e.target.value)} placeholder="Ex: Equipe de manutenção designada" />
          </div>
          <button className="btn-primary" onClick={salvar} disabled={saving}>
            {saving ? 'Salvando...' : '💾 Salvar alterações'}
          </button>
        </div>

        <div className="card">
          <p style={{ fontWeight: 600, marginBottom: '.75rem' }}>Timeline</p>
          {(denuncia.timeline || []).filter(Boolean).map((ev, i) => (
            <div key={i} style={{ display: 'flex', gap: '.6rem', marginBottom: '.6rem' }}>
              <div style={{ width: 10, height: 10, borderRadius: '50%', background: ev.concluido ? 'var(--green)' : 'var(--gray-3)', flexShrink: 0, marginTop: '.3rem' }} />
              <div>
                <div style={{ fontSize: '.88rem' }}>{ev.texto}</div>
                <div style={{ fontSize: '.72rem', color: 'var(--gray-5)' }}>{fmt(ev.created_at)}</div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
