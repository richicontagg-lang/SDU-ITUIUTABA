import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import BottomNav from '../UI/BottomNav';

const statusBadge = s => {
  const map = { Aberta: 'aberta', 'Em andamento': 'andamento', Resolvida: 'resolvida', Recusada: 'recusada' };
  return `badge badge-${map[s] || 'aberta'}`;
};

const FILTROS = ['Todos', 'Aberta', 'Em andamento', 'Resolvida', 'Recusada'];

export default function AdminPainel() {
  const nav = useNavigate();
  const [stats, setStats]       = useState(null);
  const [denuncias, setDenuncias] = useState([]);
  const [filtro, setFiltro]     = useState('Todos');
  const [loading, setLoading]   = useState(true);

  useEffect(() => {
    api.get('/admin/stats').then(r => setStats(r.data));
    fetchDenuncias(filtro);
  }, []);

  async function fetchDenuncias(f) {
    setLoading(true);
    const params = f !== 'Todos' ? { status: f } : {};
    const r = await api.get('/admin/denuncias', { params });
    setDenuncias(r.data.rows);
    setLoading(false);
  }

  function handleFiltro(f) {
    setFiltro(f);
    fetchDenuncias(f);
  }

  return (
    <div className="screen">
      <div className="page-header"><h2>⚙️ Painel Admin</h2></div>
      <div className="scroll-body">
        {stats && (
          <div className="admin-stats">
            <div className="stat-card"><div className="stat-num" style={{ color: 'var(--red)' }}>{stats.aberta}</div><div className="stat-label">Abertas</div></div>
            <div className="stat-card"><div className="stat-num" style={{ color: 'var(--amber)' }}>{stats.em_andamento}</div><div className="stat-label">Em andamento</div></div>
            <div className="stat-card"><div className="stat-num" style={{ color: 'var(--green)' }}>{stats.resolvida}</div><div className="stat-label">Resolvidas</div></div>
            <div className="stat-card"><div className="stat-num">{stats.total}</div><div className="stat-label">Total</div></div>
          </div>
        )}

        <div className="filter-tabs">
          {FILTROS.map(f => (
            <button key={f} className={filtro === f ? 'active' : ''} onClick={() => handleFiltro(f)}>{f}</button>
          ))}
        </div>

        {loading && <div style={{ textAlign: 'center', color: 'var(--gray-5)' }}>Carregando...</div>}
        {!loading && denuncias.map(d => (
          <div key={d.id} className="card" onClick={() => nav(`/admin/${d.id}`)} style={{ cursor: 'pointer' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
              <div>
                <div style={{ fontWeight: 600 }}>{d.categoria}</div>
                <div style={{ fontSize: '.78rem', color: 'var(--gray-5)' }}>{d.user_name} · {d.endereco}</div>
                <div style={{ fontSize: '.72rem', color: 'var(--gray-5)', marginTop: '.2rem' }}>#{d.protocolo}</div>
              </div>
              <span className={statusBadge(d.status)}>{d.status}</span>
            </div>
          </div>
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
