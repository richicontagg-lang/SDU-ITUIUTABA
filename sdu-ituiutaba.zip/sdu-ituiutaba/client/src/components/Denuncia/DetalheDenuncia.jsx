import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import api from '../../services/api';
import BottomNav from '../UI/BottomNav';

const statusBadge = s => {
  const map = { Aberta: 'aberta', 'Em andamento': 'andamento', Resolvida: 'resolvida', Recusada: 'recusada' };
  return `badge badge-${map[s] || 'aberta'}`;
};

export default function DetalheDenuncia() {
  const { id } = useParams();
  const nav    = useNavigate();
  const [denuncia, setDenuncia] = useState(null);
  const [loading, setLoading]   = useState(true);
  const [estrelas, setEstrelas] = useState(0);
  const [avaliado, setAvaliado] = useState(false);

  useEffect(() => {
    api.get(`/denuncias/${id}`)
      .then(r => setDenuncia(r.data))
      .finally(() => setLoading(false));
  }, [id]);

  async function avaliar(n) {
    setEstrelas(n);
    await api.post(`/denuncias/${id}/avaliar`, { estrelas: n });
    setAvaliado(true);
  }

  if (loading) return <div className="loading">Carregando...</div>;
  if (!denuncia) return <div className="loading">Denúncia não encontrada.</div>;

  const fmt = iso => new Date(iso).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });

  return (
    <div className="screen">
      <div className="page-header">
        <button className="back-btn" onClick={() => nav(-1)}>←</button>
        <div>
          <div>{denuncia.categoria}</div>
          <div style={{ fontSize: '.72rem', color: 'var(--gray-5)', fontWeight: 400 }}>#{denuncia.protocolo}</div>
        </div>
        <span className={statusBadge(denuncia.status)} style={{ marginLeft: 'auto' }}>{denuncia.status}</span>
      </div>

      <div className="scroll-body">
        {denuncia.foto_url && <img src={denuncia.foto_url} alt="foto" className="detalhe-foto" />}

        <div className="card">
          <p style={{ fontSize: '.8rem', color: 'var(--gray-5)', marginBottom: '.25rem' }}>📍 {denuncia.endereco}</p>
          <p style={{ fontSize: '.95rem' }}>{denuncia.descricao}</p>
          <p style={{ fontSize: '.75rem', color: 'var(--gray-5)', marginTop: '.5rem' }}>Enviada em {fmt(denuncia.created_at)}</p>
        </div>

        <div className="card">
          <p style={{ fontWeight: 600, marginBottom: '.75rem' }}>Acompanhamento</p>
          <div className="timeline">
            {(denuncia.timeline || []).filter(Boolean).map((ev, i) => (
              <div key={i} className="tl-item">
                <div className={`tl-dot ${ev.concluido ? 'done' : ev.progresso ? 'prog' : ''}`} />
                <div>
                  <div className="tl-text">{ev.texto}</div>
                  <div className="tl-date">{fmt(ev.created_at)}</div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {denuncia.status === 'Resolvida' && (
          <div className="card" style={{ textAlign: 'center' }}>
            <p style={{ fontWeight: 600, marginBottom: '.5rem' }}>Como foi o atendimento?</p>
            {avaliado ? (
              <p style={{ color: 'var(--green)' }}>✅ Obrigado pela avaliação!</p>
            ) : (
              <div className="stars">
                {[1, 2, 3, 4, 5].map(n => (
                  <button key={n} onClick={() => avaliar(n)}>{n <= estrelas ? '⭐' : '☆'}</button>
                ))}
              </div>
            )}
          </div>
        )}
      </div>
      <BottomNav />
    </div>
  );
}
