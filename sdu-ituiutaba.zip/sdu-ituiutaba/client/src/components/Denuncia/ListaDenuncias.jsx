import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import api from '../../services/api';
import BottomNav from '../UI/BottomNav';

const statusBadge = s => {
  const map = { Aberta: 'aberta', 'Em andamento': 'andamento', Resolvida: 'resolvida', Recusada: 'recusada' };
  return `badge badge-${map[s] || 'aberta'}`;
};

const catEmoji = { 'Buraco na via': '🕳️', 'Iluminação pública': '💡', 'Descarte de lixo': '🗑️', 'Esgoto a céu aberto': '🌊', 'Árvore caída': '🌳', 'Outro': '⚠️' };

export default function ListaDenuncias() {
  const nav = useNavigate();
  const [denuncias, setDenuncias] = useState([]);
  const [loading, setLoading]     = useState(true);

  useEffect(() => {
    api.get('/denuncias/minhas')
      .then(r => setDenuncias(r.data))
      .finally(() => setLoading(false));
  }, []);

  if (loading) return <div className="loading">Carregando...</div>;

  return (
    <div className="screen">
      <div className="page-header"><h2>Minhas Denúncias</h2></div>
      <div className="scroll-body">
        {denuncias.length === 0 && (
          <div style={{ textAlign: 'center', color: 'var(--gray-5)', paddingTop: '3rem' }}>
            <div style={{ fontSize: '2.5rem' }}>📋</div>
            <p style={{ marginTop: '.75rem' }}>Você ainda não fez nenhuma denúncia.</p>
          </div>
        )}
        {denuncias.map(d => (
          <div key={d.id} className="card" onClick={() => nav(`/denuncia/${d.id}`)} style={{ cursor: 'pointer' }}>
            <div className="denuncia-item">
              <div className="di-icon">{catEmoji[d.categoria] || '⚠️'}</div>
              <div className="di-body">
                <div className="di-title">{d.categoria}</div>
                <div className="di-sub">{d.endereco}</div>
                <div className="di-meta">
                  <span className={statusBadge(d.status)}>{d.status}</span>
                  <span style={{ fontSize: '.72rem', color: 'var(--gray-5)' }}>#{d.protocolo}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
      <BottomNav />
    </div>
  );
}
