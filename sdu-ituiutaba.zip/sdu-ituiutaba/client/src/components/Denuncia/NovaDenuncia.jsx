import { useState, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { useApp } from '../../context/AppContext';
import { useGeolocation } from '../../hooks/useGeolocation';
import api from '../../services/api';

const CATS = [
  { label: 'Buraco na via',       emoji: '🕳️' },
  { label: 'Iluminação pública',  emoji: '💡' },
  { label: 'Descarte de lixo',    emoji: '🗑️' },
  { label: 'Esgoto a céu aberto', emoji: '🌊' },
  { label: 'Árvore caída',        emoji: '🌳' },
  { label: 'Outro',               emoji: '⚠️' },
];

export default function NovaDenuncia() {
  const nav = useNavigate();
  const { showToast } = useApp();
  const { coords, loading: gpsLoading, getLocation } = useGeolocation();
  const fileRef = useRef();

  const [cat, setCat]         = useState('');
  const [end, setEnd]         = useState('');
  const [desc, setDesc]       = useState('');
  const [foto, setFoto]       = useState(null);
  const [preview, setPreview] = useState(null);
  const [submitting, setSub]  = useState(false);

  function handleFoto(e) {
    const file = e.target.files[0];
    if (!file) return;
    setFoto(file);
    const r = new FileReader();
    r.onload = ev => setPreview(ev.target.result);
    r.readAsDataURL(file);
  }

  async function handleSubmit() {
    if (!cat)  return showToast('Selecione uma categoria');
    if (!end)  return showToast('Informe o endereço aproximado');
    if (!desc) return showToast('Descreva o problema');

    setSub(true);
    try {
      const form = new FormData();
      form.append('categoria', cat);
      form.append('descricao', desc);
      form.append('endereco', end);
      if (coords) { form.append('lat', coords.lat); form.append('lng', coords.lng); }
      if (foto) form.append('foto', foto);

      const { data } = await api.post('/denuncias', form, { headers: { 'Content-Type': 'multipart/form-data' } });
      nav('/sucesso', { state: { protocolo: data.protocolo } });
    } catch (e) {
      showToast(e.response?.data?.error || 'Erro ao enviar denúncia');
    } finally {
      setSub(false);
    }
  }

  return (
    <div className="screen-nova">
      <div className="page-header">
        <button className="back-btn" onClick={() => nav(-1)}>←</button>
        <h2>Nova Denúncia</h2>
      </div>

      <div className="form-body">
        {/* Foto */}
        <div className="upload-area" onClick={() => fileRef.current.click()}>
          {preview ? (
            <img src={preview} alt="preview" className="upload-preview" />
          ) : (
            <><div className="u-icon">📷</div><p>Toque para adicionar foto</p></>
          )}
          <input ref={fileRef} type="file" accept="image/*" onChange={handleFoto} hidden />
        </div>

        {/* GPS */}
        <div className="gps-bar" onClick={getLocation}>
          <span className="gi">📍</span>
          <span>{coords ? `GPS: ${coords.lat.toFixed(5)}, ${coords.lng.toFixed(5)}` : 'Toque para obter localização'}</span>
          <span className="gps-status">{gpsLoading ? '⟳' : coords ? '✓' : ''}</span>
        </div>

        {/* Categorias */}
        <p className="field-label">Categoria do problema</p>
        <div className="cat-grid">
          {CATS.map(c => (
            <button key={c.label} className={`cat-btn ${cat === c.label ? 'active' : ''}`} onClick={() => setCat(c.label)}>
              <span className="ci">{c.emoji}</span>{c.label}
            </button>
          ))}
        </div>

        {/* Endereço */}
        <div className="field">
          <label>Endereço aproximado</label>
          <input value={end} onChange={e => setEnd(e.target.value)} placeholder="Ex: Av. Getúlio Vargas, 500" />
        </div>

        {/* Descrição */}
        <div className="field" style={{ marginTop: '1rem' }}>
          <label>Descrição do problema</label>
          <textarea value={desc} onChange={e => setDesc(e.target.value)} placeholder="Descreva o problema com detalhes..." />
        </div>

        <button className="btn-primary" onClick={handleSubmit} disabled={submitting}>
          {submitting ? 'Enviando...' : '📤 Enviar Denúncia'}
        </button>
      </div>
    </div>
  );
}
