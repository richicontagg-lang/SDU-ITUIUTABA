import { useLocation, useNavigate } from 'react-router-dom';

export default function Sucesso() {
  const { state } = useLocation();
  const nav = useNavigate();

  return (
    <div className="sucesso-screen">
      <div className="sucesso-icon">✅</div>
      <h2>Denúncia enviada!</h2>
      <p style={{ color: 'var(--gray-5)', marginTop: '.5rem' }}>Seu protocolo é:</p>
      <div className="sucesso-protocolo">{state?.protocolo || '—'}</div>
      <p style={{ color: 'var(--gray-5)', fontSize: '.9rem', maxWidth: '280px' }}>
        Guarde esse número para acompanhar o andamento da sua denúncia.
      </p>
      <button className="btn-primary" style={{ maxWidth: '260px', marginTop: '2rem' }} onClick={() => nav('/minhas')}>
        Ver minhas denúncias
      </button>
      <button
        onClick={() => nav('/')}
        style={{ background: 'none', border: 'none', color: 'var(--gray-5)', marginTop: '.75rem', cursor: 'pointer', fontSize: '.9rem' }}
      >
        Voltar ao mapa
      </button>
    </div>
  );
}
