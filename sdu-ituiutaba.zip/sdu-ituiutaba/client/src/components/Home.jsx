import { useState, useEffect, lazy, Suspense } from 'react';
import { useNavigate } from 'react-router-dom';
import { useGeolocation } from '../hooks/useGeolocation';
import api from '../services/api';
import Topbar from './UI/Topbar';
import BottomNav from './UI/BottomNav';

const MapView = lazy(() => import('./Map/MapView'));

const STATUS_FILTERS = ['Todos', 'Aberta', 'Em andamento', 'Resolvida'];

export default function Home() {
  const nav = useNavigate();
  const { coords, getLocation } = useGeolocation();
  const [denuncias, setDenuncias] = useState([]);
  const [filtro, setFiltro] = useState('Todos');

  useEffect(() => {
    api.get('/denuncias').then(r => setDenuncias(r.data)).catch(() => {});
  }, []);

  const filtered = filtro === 'Todos' ? denuncias : denuncias.filter(d => d.status === filtro);

  return (
    <div className="home-screen">
      <Topbar />
      <div className="map-wrap">
        <div className="map-filter">
          {STATUS_FILTERS.map(f => (
            <button key={f} className={filtro === f ? 'active' : ''} onClick={() => setFiltro(f)}>
              {f}
            </button>
          ))}
        </div>
        <Suspense fallback={<div className="loading">Carregando mapa...</div>}>
          <MapView
            denuncias={filtered}
            userCoords={coords}
            onPinClick={d => nav(`/denuncia/${d.id}`)}
          />
        </Suspense>
        <button className="fab" onClick={() => nav('/nova')} title="Nova Denúncia">+</button>
      </div>
      <BottomNav />
    </div>
  );
}
