import { useEffect } from 'react';
import { MapContainer, TileLayer, Marker, Popup, useMap } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

const makeIcon = (color) =>
  L.divIcon({
    className: '',
    html: `<div style="background:${color};width:20px;height:20px;border-radius:50% 50% 50% 0;transform:rotate(-45deg);box-shadow:0 2px 6px rgba(0,0,0,.3)"></div>`,
    iconSize: [20, 20],
  });

const icons = {
  Aberta:          makeIcon('#dc2626'),
  'Em andamento':  makeIcon('#d97706'),
  Resolvida:       makeIcon('#1d6f42'),
  Recusada:        makeIcon('#9ca3af'),
};

function FlyToUser({ coords }) {
  const map = useMap();
  useEffect(() => { if (coords) map.flyTo([coords.lat, coords.lng], 15); }, [coords, map]);
  return null;
}

export default function MapView({ denuncias = [], userCoords, onPinClick }) {
  const center = [-18.9745, -49.4634];

  return (
    <MapContainer center={center} zoom={14} style={{ height: '100%', width: '100%' }}>
      <TileLayer
        attribution='© <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      />
      {userCoords && <FlyToUser coords={userCoords} />}
      {denuncias.filter(d => d.lat && d.lng).map(d => (
        <Marker key={d.id} position={[parseFloat(d.lat), parseFloat(d.lng)]} icon={icons[d.status] || icons.Aberta}>
          <Popup>
            <strong>{d.categoria}</strong><br />
            {d.endereco}<br />
            <span style={{ fontSize: '.75rem', color: '#6b7280' }}>#{d.protocolo}</span><br />
            <button
              onClick={() => onPinClick?.(d)}
              style={{ marginTop: '6px', background: '#1d6f42', color: '#fff', border: 'none', borderRadius: '6px', padding: '4px 10px', cursor: 'pointer', fontSize: '.78rem' }}
            >
              Ver detalhes
            </button>
          </Popup>
        </Marker>
      ))}
    </MapContainer>
  );
}
