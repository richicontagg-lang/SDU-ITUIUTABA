import { useNavigate, useLocation } from 'react-router-dom';
import { useApp } from '../../context/AppContext';

const tabs = [
  { path: '/',       icon: '🗺️',  label: 'Mapa'     },
  { path: '/nova',   icon: '➕',  label: 'Denunciar' },
  { path: '/minhas', icon: '📋',  label: 'Minhas'    },
];

const adminTab = { path: '/admin', icon: '⚙️', label: 'Admin' };

export default function BottomNav() {
  const nav      = useNavigate();
  const { pathname } = useLocation();
  const { user } = useApp();

  const items = user?.role === 'admin' || user?.role === 'gestor'
    ? [...tabs, adminTab]
    : tabs;

  return (
    <nav className="bottom-nav">
      {items.map(t => (
        <button
          key={t.path}
          className={`nav-btn ${pathname === t.path ? 'active' : ''}`}
          onClick={() => nav(t.path)}
        >
          <span className="ni">{t.icon}</span>
          {t.label}
        </button>
      ))}
    </nav>
  );
}
