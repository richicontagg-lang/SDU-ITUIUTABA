import { useApp } from '../../context/AppContext';

export default function Topbar() {
  const { user } = useApp();
  const initials = user?.name?.split(' ').map(w => w[0]).slice(0, 2).join('').toUpperCase() || '?';

  return (
    <div className="topbar">
      <div>
        <div className="topbar-title">SDU Ituiutaba</div>
        <div className="topbar-sub">Sistema de Denúncias Urbanas</div>
      </div>
      <div className="topbar-avatar">{initials}</div>
    </div>
  );
}
