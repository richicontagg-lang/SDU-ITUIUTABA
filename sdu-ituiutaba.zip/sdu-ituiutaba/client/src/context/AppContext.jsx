import { createContext, useContext, useState, useEffect } from 'react';
import api from '../services/api';

const AppCtx = createContext();

export function AppProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [token, setToken]     = useState(localStorage.getItem('sdu_token'));
  const [toast, setToast]     = useState('');
  const [loading, setLoading] = useState(!!localStorage.getItem('sdu_token'));

  useEffect(() => {
    if (!token) { setLoading(false); return; }
    api.get('/auth/me')
      .then(r => setUser(r.data))
      .catch(() => logout())
      .finally(() => setLoading(false));
  }, [token]);

  function login(tkn, userData) {
    localStorage.setItem('sdu_token', tkn);
    setToken(tkn);
    setUser(userData);
  }

  function logout() {
    localStorage.removeItem('sdu_token');
    setToken(null);
    setUser(null);
  }

  function showToast(msg, duration = 2800) {
    setToast(msg);
    setTimeout(() => setToast(''), duration);
  }

  return (
    <AppCtx.Provider value={{ user, token, loading, login, logout, toast, showToast }}>
      {children}
    </AppCtx.Provider>
  );
}

export const useApp = () => useContext(AppCtx);
