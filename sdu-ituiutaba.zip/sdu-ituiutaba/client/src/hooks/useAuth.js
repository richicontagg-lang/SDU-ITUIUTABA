import { useApp } from '../context/AppContext';

export function useAuth() {
  const { user, token, loading, login, logout } = useApp();
  return { user, token, loading, login, logout, isAdmin: user?.role === 'admin' || user?.role === 'gestor' };
}
