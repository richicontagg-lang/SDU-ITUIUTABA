import { useState } from 'react';

export function useGeolocation() {
  const [coords, setCoords]   = useState(null);
  const [error, setError]     = useState(null);
  const [loading, setLoading] = useState(false);

  function getLocation() {
    setLoading(true);
    if (!navigator.geolocation) {
      setCoords({ lat: -18.9745, lng: -49.4634 });
      setLoading(false);
      return;
    }
    navigator.geolocation.getCurrentPosition(
      pos => {
        setCoords({ lat: pos.coords.latitude, lng: pos.coords.longitude });
        setLoading(false);
      },
      () => {
        // Fallback: centro de Ituiutaba
        setCoords({ lat: -18.9745, lng: -49.4634 });
        setLoading(false);
      }
    );
  }

  return { coords, error, loading, getLocation };
}
