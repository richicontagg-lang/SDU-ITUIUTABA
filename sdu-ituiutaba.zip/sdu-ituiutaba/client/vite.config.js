import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
  plugins: [
    react(),
    VitePWA({
      registerType: 'autoUpdate',
      includeAssets: ['icons/*.png'],
      manifest: {
        name: 'SDU Ituiutaba',
        short_name: 'SDU',
        description: 'Sistema de Denúncias Urbanas de Ituiutaba',
        theme_color: '#1d6f42',
        background_color: '#ffffff',
        display: 'standalone',
        start_url: '/',
        icons: [
          { src: 'icons/icon-192.png', sizes: '192x192', type: 'image/png' },
          { src: 'icons/icon-512.png', sizes: '512x512', type: 'image/png', purpose: 'any maskable' }
        ]
      },
      workbox: {
        runtimeCaching: [
          {
            urlPattern: /\/api\/denuncias$/,
            handler: 'NetworkFirst',
            options: { cacheName: 'api-denuncias', expiration: { maxAgeSeconds: 300 } }
          }
        ]
      }
    })
  ],
  server: { proxy: { '/api': 'http://localhost:3001' } }
});
