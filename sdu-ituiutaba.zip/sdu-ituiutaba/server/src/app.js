const express = require('express');
const cors = require('cors');
const helmet = require('helmet');
const rateLimit = require('express-rate-limit');
require('dotenv').config();

const authRoutes      = require('./routes/auth');
const denunciasRoutes = require('./routes/denuncias');
const adminRoutes     = require('./routes/admin');

const app = express();

// Segurança
app.use(helmet());
app.use(cors({ origin: process.env.CLIENT_URL, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(rateLimit({ windowMs: 15 * 60 * 1000, max: 100 }));

// Rotas
app.use('/api/auth',      authRoutes);
app.use('/api/denuncias', denunciasRoutes);
app.use('/api/admin',     adminRoutes);

// Health check
app.get('/api/health', (_, res) => res.json({ ok: true, env: process.env.NODE_ENV }));

// Erro global
app.use((err, req, res, next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.message || 'Erro interno' });
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`✅ API SDU rodando na porta ${PORT}`));
