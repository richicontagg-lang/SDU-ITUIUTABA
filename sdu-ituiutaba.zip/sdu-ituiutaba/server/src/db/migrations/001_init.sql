-- Extensão para UUID
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Tabela de usuários
CREATE TABLE users (
  id          UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name        VARCHAR(120) NOT NULL,
  email       VARCHAR(200) UNIQUE NOT NULL,
  password    VARCHAR(255) NOT NULL,
  role        VARCHAR(20) DEFAULT 'cidadao' CHECK (role IN ('cidadao','admin','gestor')),
  created_at  TIMESTAMPTZ DEFAULT NOW()
);

-- Tabela de denúncias
CREATE TABLE denuncias (
  id           SERIAL PRIMARY KEY,
  protocolo    VARCHAR(20) UNIQUE NOT NULL,
  user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  categoria    VARCHAR(60) NOT NULL,
  descricao    TEXT NOT NULL,
  endereco     VARCHAR(255) NOT NULL,
  lat          DECIMAL(10,7),
  lng          DECIMAL(10,7),
  foto_url     VARCHAR(500),
  status       VARCHAR(30) DEFAULT 'Aberta'
                CHECK (status IN ('Aberta','Em andamento','Resolvida','Recusada')),
  created_at   TIMESTAMPTZ DEFAULT NOW(),
  updated_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Timeline de status
CREATE TABLE timeline_eventos (
  id           SERIAL PRIMARY KEY,
  denuncia_id  INT REFERENCES denuncias(id) ON DELETE CASCADE,
  texto        VARCHAR(255) NOT NULL,
  progresso    BOOLEAN DEFAULT FALSE,
  concluido    BOOLEAN DEFAULT FALSE,
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Avaliações
CREATE TABLE avaliacoes (
  id           SERIAL PRIMARY KEY,
  denuncia_id  INT REFERENCES denuncias(id) ON DELETE CASCADE,
  user_id      UUID REFERENCES users(id) ON DELETE SET NULL,
  estrelas     SMALLINT CHECK (estrelas BETWEEN 1 AND 5),
  created_at   TIMESTAMPTZ DEFAULT NOW()
);

-- Índices para performance
CREATE INDEX idx_denuncias_status   ON denuncias(status);
CREATE INDEX idx_denuncias_user     ON denuncias(user_id);
CREATE INDEX idx_denuncias_geo      ON denuncias(lat, lng);
CREATE INDEX idx_denuncias_created  ON denuncias(created_at DESC);

-- Função para updated_at automático
CREATE OR REPLACE FUNCTION touch_updated_at()
RETURNS TRIGGER AS $$
BEGIN NEW.updated_at = NOW(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER denuncias_updated_at
  BEFORE UPDATE ON denuncias
  FOR EACH ROW EXECUTE FUNCTION touch_updated_at();

-- Seed admin (senha: admin123 — troque em produção)
INSERT INTO users (name, email, password, role)
VALUES ('Admin SDU', 'admin@ituiutaba.mg.gov.br',
        '$2b$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
