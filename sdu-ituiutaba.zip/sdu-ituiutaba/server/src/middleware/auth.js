const jwt = require('jsonwebtoken');

function requireAuth(req, res, next) {
  const header = req.headers.authorization;
  if (!header?.startsWith('Bearer ')) return res.status(401).json({ error: 'Não autenticado' });

  try {
    const token = header.split(' ')[1];
    req.user = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Token inválido ou expirado' });
  }
}

requireAuth.requireAdmin = function (req, res, next) {
  requireAuth(req, res, () => {
    if (!['admin', 'gestor'].includes(req.user.role))
      return res.status(403).json({ error: 'Acesso negado' });
    next();
  });
};

module.exports = requireAuth;
