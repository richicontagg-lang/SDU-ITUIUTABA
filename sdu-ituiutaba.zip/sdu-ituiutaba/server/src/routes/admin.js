const router = require('express').Router();
const pool   = require('../db/pool');
const { requireAdmin } = require('../middleware/auth');

// GET /api/admin/denuncias — todas
router.get('/denuncias', requireAdmin, async (req, res, next) => {
  try {
    const { status, page = 1 } = req.query;
    const limit = 20, offset = (page - 1) * limit;
    let query, params;

    if (status) {
      query = `SELECT d.*, u.name AS user_name, u.email AS user_email,
        COALESCE((SELECT json_agg(te ORDER BY te.created_at) FROM timeline_eventos te WHERE te.denuncia_id=d.id), '[]') AS timeline
       FROM denuncias d LEFT JOIN users u ON u.id=d.user_id
       WHERE d.status = $3 ORDER BY d.created_at DESC LIMIT $1 OFFSET $2`;
      params = [limit, offset, status];
    } else {
      query = `SELECT d.*, u.name AS user_name, u.email AS user_email,
        COALESCE((SELECT json_agg(te ORDER BY te.created_at) FROM timeline_eventos te WHERE te.denuncia_id=d.id), '[]') AS timeline
       FROM denuncias d LEFT JOIN users u ON u.id=d.user_id
       ORDER BY d.created_at DESC LIMIT $1 OFFSET $2`;
      params = [limit, offset];
    }

    const { rows } = await pool.query(query, params);
    const count = await pool.query(
      `SELECT COUNT(*) FROM denuncias ${status ? `WHERE status=$1` : ``}`,
      status ? [status] : []
    );
    res.json({ rows, total: parseInt(count.rows[0].count), page, limit });
  } catch (e) { next(e); }
});

// GET /api/admin/stats — KPIs
router.get('/stats', requireAdmin, async (req, res, next) => {
  try {
    const { rows } = await pool.query(`
      SELECT
        COUNT(*) FILTER (WHERE status='Aberta')        AS aberta,
        COUNT(*) FILTER (WHERE status='Em andamento')  AS em_andamento,
        COUNT(*) FILTER (WHERE status='Resolvida')     AS resolvida,
        COUNT(*) FILTER (WHERE status='Recusada')      AS recusada,
        COUNT(*)                                        AS total,
        ROUND(AVG(EXTRACT(EPOCH FROM (updated_at-created_at))/3600)::numeric,1) AS media_horas
      FROM denuncias
    `);
    res.json(rows[0]);
  } catch (e) { next(e); }
});

// PATCH /api/admin/denuncias/:id/status
router.patch('/denuncias/:id/status', requireAdmin, async (req, res, next) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { status, nota } = req.body;
    const validos = ['Em andamento', 'Resolvida', 'Recusada', 'Aberta'];
    if (!validos.includes(status)) return res.status(400).json({ error: 'Status inválido' });

    await client.query('UPDATE denuncias SET status=$1 WHERE id=$2', [status, req.params.id]);

    const labels = {
      'Em andamento': 'Equipe designada',
      'Resolvida': 'Problema resolvido ✓',
      'Recusada': 'Denúncia recusada',
    };
    if (labels[status]) {
      await client.query(
        `INSERT INTO timeline_eventos(denuncia_id,texto,progresso,concluido) VALUES($1,$2,$3,$4)`,
        [
          req.params.id,
          nota || labels[status],
          status === 'Em andamento',
          status === 'Resolvida' || status === 'Recusada',
        ]
      );
    }
    await client.query('COMMIT');
    res.json({ ok: true, status });
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

module.exports = router;
