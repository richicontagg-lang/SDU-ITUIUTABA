const router      = require('express').Router();
const pool        = require('../db/pool');
const requireAuth = require('../middleware/auth');
const multer      = require('multer');

// Se Cloudinary não estiver configurado, salva localmente
let uploadToCloud = null;
if (process.env.CLOUDINARY_CLOUD_NAME) {
  const cloudinary = require('cloudinary').v2;
  cloudinary.config({
    cloud_name: process.env.CLOUDINARY_CLOUD_NAME,
    api_key:    process.env.CLOUDINARY_API_KEY,
    api_secret: process.env.CLOUDINARY_API_SECRET,
  });
  uploadToCloud = cloudinary;
}

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 5 * 1024 * 1024 } });

// Gera protocolo único: SDU-YYYYMM-XXXX
function geraProtocolo(id) {
  const d = new Date();
  return `SDU-${d.getFullYear()}${String(d.getMonth() + 1).padStart(2, '0')}-${String(id).padStart(4, '0')}`;
}

// GET /api/denuncias — pública (mapa)
router.get('/', async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT id, protocolo, categoria, endereco, lat, lng, status, foto_url, created_at
       FROM denuncias ORDER BY created_at DESC LIMIT 200`
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /api/denuncias/minhas — autenticado
router.get('/minhas', requireAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT d.*,
        COALESCE(json_agg(te ORDER BY te.created_at) FILTER (WHERE te.id IS NOT NULL), '[]') AS timeline
       FROM denuncias d
       LEFT JOIN timeline_eventos te ON te.denuncia_id = d.id
       WHERE d.user_id = $1
       GROUP BY d.id ORDER BY d.created_at DESC`,
      [req.user.id]
    );
    res.json(rows);
  } catch (e) { next(e); }
});

// GET /api/denuncias/:id
router.get('/:id', requireAuth, async (req, res, next) => {
  try {
    const { rows } = await pool.query(
      `SELECT d.*,
        COALESCE(json_agg(te ORDER BY te.created_at) FILTER (WHERE te.id IS NOT NULL), '[]') AS timeline
       FROM denuncias d
       LEFT JOIN timeline_eventos te ON te.denuncia_id = d.id
       WHERE d.id = $1 GROUP BY d.id`,
      [req.params.id]
    );
    if (!rows.length) return res.status(404).json({ error: 'Não encontrada' });
    res.json(rows[0]);
  } catch (e) { next(e); }
});

// POST /api/denuncias — cria nova denúncia
router.post('/', requireAuth, upload.single('foto'), async (req, res, next) => {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const { categoria, descricao, endereco, lat, lng } = req.body;
    if (!categoria || !descricao || !endereco)
      return res.status(400).json({ error: 'Campos obrigatórios faltando' });

    let foto_url = null;
    if (req.file && uploadToCloud) {
      const b64 = req.file.buffer.toString('base64');
      const dataUri = `data:${req.file.mimetype};base64,${b64}`;
      const result = await uploadToCloud.uploader.upload(dataUri, { folder: 'sdu-ituiutaba' });
      foto_url = result.secure_url;
    }

    const { rows } = await client.query(
      `INSERT INTO denuncias(user_id,categoria,descricao,endereco,lat,lng,foto_url,protocolo)
       VALUES($1,$2,$3,$4,$5,$6,$7,'TEMP') RETURNING id`,
      [req.user.id, categoria, descricao, endereco, lat || null, lng || null, foto_url]
    );
    const id = rows[0].id;
    const protocolo = geraProtocolo(id);
    await client.query('UPDATE denuncias SET protocolo=$1 WHERE id=$2', [protocolo, id]);

    // Timeline inicial
    await client.query(
      `INSERT INTO timeline_eventos(denuncia_id,texto,concluido)
       VALUES($1,'Denúncia recebida',true),($1,'Aguardando análise...',false)`,
      [id]
    );

    await client.query('COMMIT');

    const { rows: full } = await pool.query(
      `SELECT d.*,
        COALESCE(json_agg(te ORDER BY te.created_at) FILTER (WHERE te.id IS NOT NULL), '[]') AS timeline
       FROM denuncias d LEFT JOIN timeline_eventos te ON te.denuncia_id=d.id
       WHERE d.id=$1 GROUP BY d.id`, [id]
    );
    res.status(201).json(full[0]);
  } catch (e) { await client.query('ROLLBACK'); next(e); }
  finally { client.release(); }
});

// POST /api/denuncias/:id/avaliar
router.post('/:id/avaliar', requireAuth, async (req, res, next) => {
  try {
    const { estrelas } = req.body;
    if (!estrelas || estrelas < 1 || estrelas > 5)
      return res.status(400).json({ error: 'Avaliação inválida' });
    await pool.query(
      'INSERT INTO avaliacoes(denuncia_id,user_id,estrelas) VALUES($1,$2,$3)',
      [req.params.id, req.user.id, estrelas]
    );
    res.json({ ok: true });
  } catch (e) { next(e); }
});

module.exports = router;
